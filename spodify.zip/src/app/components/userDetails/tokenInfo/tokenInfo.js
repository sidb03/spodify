import React, { Component } from 'react';

import './tokenInfo.css';

class TokenInfo extends Component {
    render() {
        return (
            <div className="tokenInfo">
                <p>
                    <span className="key">my address: </span> 
                    <span className="value">0xC6674…</span>
                </p>
                <p>
                    <span className="key">balance: </span> 
                    <span className="value">3.42 ETH</span>
                </p>
            </div>
        );
    }
}

export default TokenInfo;