import React, { Component, PureComponent } from "react";
import { Row, Col, Card, Modal } from "antd";
import aviciiCover from "../../../../images/covers/avicii.png";
import armada from "../../../../images/covers/armada.jpg";
import farEast from "../../../../images/covers/far-east.jpg";

import "./fanTokens.css";

const tokensList = [
  {
    artist: "Far East Movement",
    tokens: 15,
    tokenName: "S-FEM",
    cover: farEast
  },
  {
    artist: "Dash Berlin",
    tokens: 8,
    tokenName: "S-DBN",
    cover: armada
  },
  {
    artist: "Alesso",
    tokens: 4,
    tokenName: "S-ALO",
    cover: aviciiCover
  }
];

class TokenComp extends PureComponent {
  render() {
    const { token, showModal } = this.props;
    const { cover, artist, tokens, tokenName } = token;
    return (
      <Row className="token-item">
        <Col xs={2} sm={3} xl={2}>
          <img src={cover} alt="artist-icon" />
        </Col>
        <Col xs={7} sm={9} lg={7} xl={8}>
          <p className="artist">{artist}</p>
        </Col>
        <Col xs={7} sm={5} lg={7} xl={7}>
            <p style={{textAlign: 'right'}}>
                <span className="tokens">{tokens}</span>
                <span className="token-name">{tokenName}</span>
            </p>
        </Col>
        <Col xs={7} xl={6} style={{textAlign: 'right'}}>
            <button className="btn send-token" onClick={() => showModal(tokenName)}>send tokens</button>
        </Col>
      </Row>
    );
  }
}

class FanTokens extends Component {
  constructor(props) {
    super(props);

    this.state = {
      visible: false,
      activeToken: {},
      tokensToSend: 0
    }

    this.updateToken = this.updateToken.bind(this);
  }
  renderTokens = tokenList => {
    const list = [];
    tokenList.map((item, index) => {
      return list.push(<TokenComp token={item} key={index} showModal={this.showModal} />);
    });
    return <div> {list} </div>;
  };
  showModal = (tokenName) => {

    let t = tokensList.findIndex(t => t.tokenName === tokenName);
    if(t >= 0) {
      this.setState({ 
        visible: true,
        activeToken: tokensList[t] 
      });
    }
  };
  handleCancel = () => {
    this.setState({ visible: false, tokensToSend: 0 });
  };
  updateToken = event => {
    const tokensToSend = event.target.value;
    if(tokensToSend <= this.state.activeToken.tokens) {
      this.setState({ tokensToSend });
    }
  }

  render() {
    const { activeToken } = this.state;
    return (
      <div className="template-content fan-tokens">
        <Modal title="Buy Song"
            visible={this.state.visible}
            onOk={this.handleOk}
            okText="Buy"
            footer={null}
            onCancel={this.handleCancel}
        >
        <div className="token-form">
            <div className="block">
              <p className="key">CURRENT BALANCE: </p> 
              <p className="value"><span className="total">{activeToken.tokens} </span><span className="name">{activeToken.tokenName}</span></p>
            </div>
            <div className="block">
              <p className="key"># TOKENS TO SEND: </p> 
              <p className="value"><input type="text" className="token-input" value={this.state.tokensToSend} onChange={this.updateToken} /></p>
            </div>
            <div className="block">
              <p className="key">ETH ADDRESS OF RECIPIENT: </p> 
              <p className="value"><input type="text" className="token-input" /></p>
            </div>
            <div className="block" style={{textAlign: 'right', paddingRight:'5%'}}>
              <button className="btn btn-sendtoken">Send {this.state.tokensToSend} {activeToken.tokenName}</button>
            </div>
        </div>
        </Modal>

        <h1 className="template-heading">
          <span>My Fan Tokens</span>
        </h1>
        <Card>
            { this.renderTokens(tokensList) }
        </Card>
      </div>
    );
  }
}

export default FanTokens;
