import React, { Component, PureComponent } from 'react';
import { Row, Col, Card, Modal } from 'antd';
import aviciiCover from '../../../../images/covers/avicii.png';
import armada from '../../../../images/covers/armada.jpg';
import farEast from '../../../../images/covers/far-east.jpg';

import './marketplace.css';

const { Meta } = Card;
const songsList = [
    {
        cover: aviciiCover,
        name: 'Hello brother',
        artist: 'Avicii',
        price: 2.40
    },
    {
        cover: armada,
        name: 'World falls apart',
        artist: 'Dash berlin',
        price: 2.90

    },
    {
        cover: farEast,
        name: 'Hello brother',
        artist: 'Avicii',
        price: 3.00

    },
    {
        cover: aviciiCover,
        name: 'Hello brother',
        artist: 'Avicii',
        price: 2.10
    }
];

class SongCard extends PureComponent {
    buySong = cover => {
        console.log("cover", cover, this.props);
        this.props.open(cover);
    };
    render() {
        const { cover, name, artist, price } = this.props;
        return(
            <Col xs={24} md={12} xxl={6} onClick={() => this.buySong(cover)}>
               <Card
                    hoverable
                    cover={<img alt="song-cover" src={cover} />}
                >
                    <p className="price">${price}</p>
                    <Meta
                    title={name}
                    description={artist}
                    />
                </Card>
            </Col>
        );
    }
}

function RenderSongCards(props) {
    const { songsList, open } = props;
    const totalCards = [];

    songsList.map((item, index) => {
        return totalCards.push( <SongCard cover={item.cover} name={item.name} artist={item.artist} price={item.price} open={open} key={index} /> );
    });
    console.log("total cards", totalCards);
return ( <div> {totalCards} </div>);
}

class Marketplace extends Component {
    state = {
        visible: false,
        activeSong: {}
    };
    handleOpen = cover => {

        let c = songsList.findIndex(c => c.cover === cover);
        if(c >= 0) {
            console.log("open modal");
            this.setState({ visible: true,
                activeSong: songsList[c]
            });
        }
    };
    handleCancel = () => {
        this.setState({ visible: false });
    };
    render() {
        const { activeSong } = this.state;
        return(
            <div className="template-content marketplace">
                <Modal title="Buy Song"
                    visible={this.state.visible}
                    onOk={this.handleOk}
                    okText="Buy"
                    onCancel={this.handleCancel}
                >
                <div>
                    <img src={activeSong.cover} alt="song-cover" className="coverimg" />
                    <p className="song-name">{activeSong.name}</p>
                    <p className="artist-name">{activeSong.artist}</p>
                    <p className="price">
                        <span className="key">USD PRICE: </span> <span className="value">${activeSong.price}</span> <br />
                        <span className="key">ETH PRICE: </span> <span className="value">0.12151515 ETH</span>
                    </p>
                </div>
                </Modal>
                <h1 className="template-heading"><span>Marketplace</span></h1>
                <Row>
                    <Col span={24}>
                        <RenderSongCards songsList={songsList} open={this.handleOpen} />
                    </Col>
                </Row>
            </div>
        );
    };
}

export default Marketplace;