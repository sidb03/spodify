import React, { Component, PureComponent } from 'react';

class About extends Component {
    render() {
        return(
            <div className="template-content">
                <h1 className="template-heading"><span>About Spodify</span></h1>

            </div>
        );
    };
}

export default About;