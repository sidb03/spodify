import React, { Component, PureComponent } from 'react';
import { Row, Col, Card } from 'antd';
import ReactAudioPlayer from 'react-audio-player';

import aviciiCover from '../../../../images/covers/avicii.png';
import armada from '../../../../images/covers/armada.jpg';
import farEast from '../../../../images/covers/far-east.jpg';

import mpsong from '../../../../audio/song.mp3'

import './mySongs.css';
const { Meta } = Card;
const songsList = [
    {
        cover: aviciiCover,
        name: 'Hello brother',
        artist: 'Avicii'
    },
    {
        cover: armada,
        name: 'World falls apart',
        artist: 'Dash berlin'

    },
    {
        cover: farEast,
        name: 'Hello brother',
        artist: 'Avicii'

    },
    {
        cover: aviciiCover,
        name: 'Hello brother',
        artist: 'Avicii'
    }
];

class MusicPlayer extends PureComponent {
    render() {
        const { song } = this.props;
        const changeVolume = () => {
            console.log("element", this.rap);
        };
        return (
            <Col span={24} className="music-player">
                <div className="song-cover">
                    <img src={song.cover} />
                </div>
                <div className="audio-player">
                <ReactAudioPlayer
                    ref={(element) => { this.rap = element; }}
                    onVolumeChanged = {changeVolume}
                    src={mpsong}
                    autoPlay
                    controls
                    controlsList="nodownload"
                />
                </div>
            </Col>
        );
    }
}

class SongCard extends PureComponent {
    render() {
        const { cover, name, artist, playSong } = this.props;        
        return(
            <Col xs={24} sm={12} xxl={6}>
               <Card
                    hoverable
                    cover={<img alt="example" src={cover}
                    onClick={() => playSong(cover)} />}
                >
                    <Meta
                    title={name}
                    description={artist}
                    />
                </Card>
            </Col>
        );
    }
}

function RenderSongCards(props) {
    const { songsList, playSong } = props;
    const totalCards = [];

    songsList.map((item, index) => {
        return totalCards.push( <SongCard cover={item.cover} name={item.name} artist={item.artist} playSong={playSong} key={index} /> );
    });
    console.log("total cards", totalCards);
return ( <div> {totalCards} </div>);
}

class MySongs extends Component {
    state = {
        songPlaying: null
    };
    toggleMusicPlayer = cover => {
        let s = songsList.findIndex(s => s.cover === cover);
        if(s >= 0) {
            this.setState({ songPlaying: songsList[s] });
        } else {
            this.setState({ songPlaying: null });
        }
    };
    render() {
        let heading;
        let template;

        if(this.state.songPlaying === null) {
            template = <RenderSongCards songsList={songsList} playSong={this.toggleMusicPlayer} />;
            heading = <h1 className="template-heading"><span>My Songs</span></h1>
        } else {
            template = <MusicPlayer song={this.state.songPlaying} />;
            heading = <p className="sec-heading" onClick={() => this.toggleMusicPlayer(null)}>{`< back to all songs`}</p>
        }

        return(
            <div className="template-content">
                {heading}
                <Row>
                    <Col span={24}>
                        {template}
                    </Col>
                </Row>
            </div>
        );
    };
}

export default MySongs;