import React, { Component, PureComponent } from 'react';
import { Row, Col, Radio, Affix } from 'antd';

import './artistPolls.css';
import clock from '../../../../images/clock.svg';
import farEast from '../../../../images/covers/far-east.jpg';

const RadioGroup = Radio.Group;

class Options extends Component {
    render() {
        const radioStyle = {
            display: 'block',
            height: '30px',
            lineHeight: '30px',
        };
        const { value } = this.props;  
        return (
            <Radio style={radioStyle} value={1}>{value}</Radio>
        );
    }
}

class Poll extends PureComponent {
    renderOptions = (options) => {
        console.log("poll options", options);
        const optionsList = [];
        options.map((item, index) => {
            return optionsList.push(<Options value={item.value} key={index} />)
        });
        return ( [optionsList] );
    }
    render() {
        const { pollInfo } = this.props;
        const { artist, question, tokens, options } = pollInfo;
        console.log("props of polls", pollInfo, artist);
        return (
            <Col xs={24} lg={12} xxl={8}>
                <div className="polls-box">
                    <div className="polls-box-head">
                        <p style={{paddingBottom:'20px'}}>
                            <img src={artist.cover} className="artist-icon" alt="icon" /> <span className="artist">{artist.name}</span>
                        </p>
                        <p>
                            <span className="question">
                                {question}
                            </span>
                        </p>
                        <p>
                            <span className="tokensleft">
                                <img src={clock} alt="clock-icon" /> {tokens.left} tokens until poll closes. {tokens.total} tokens received so far
                            </span>
                        </p>
                    </div>
                    <div className="polls-box-body">
                        <div className="poll-options">
                        <RadioGroup onChange={this.submitToken} value={options[0].value}>
                            { this.renderOptions(options) }
                        </RadioGroup>
                        </div>
                        <div>
                            <p className="left-token">You have <span>10 fan tokens</span> for this artist</p>
                        </div>
                        <div className="poll-input">
                            <input type="text" className="token-input" placeholder="Enter # of tokens to vote with" />
                            <button className="btn btn-submitpoll">Submit vote</button>
                        </div>
                    </div>
                </div>
            </Col>
        );       
    }
}

function RenderPolls(props) {
    let { pollsList } = props;
    let pollsToRender = [];

    pollsList.map((item, index) => {
        return pollsToRender.push(<Poll pollInfo={item} key={index} />);
    });
    return ( <div>{pollsToRender}</div> );
}

class ArtistPolls extends Component {
    state = {
        mode: 'recent'
    }
    sortPolls = e => {
        console.log("sort polls", e);
        let mode = e.target.value;
        this.setState({ mode });
    };

    activePolls = [
        {
            artist: {
                name: 'Far East Movement',
                cover: farEast
            },
            question: 'Which city should we come to next for a live show?',
            tokens: {
                total: 20,
                left: 15
            },
            options: [
                {
                    index: 0,
                    value: 'New York City'
                }, 
                {
                    index: 1,
                    value: 'Paris'
                },
                {
                    index: 2,
                    value: 'Austin, Texas'
                },
                {
                    index: 3,
                    value: 'Barcelona'
                }
            ]
        },
        {
            artist: {
                name: 'Far East Movement',
                cover: farEast
            },
            question: 'Which city should we come to next for a live show?',
            tokens: {
                total: 20,
                left: 15
            },
            options: [
                {
                    index: 0,
                    value: 'New York City'
                }, 
                {
                    index: 1,
                    value: 'Paris'
                },
                {
                    index: 2,
                    value: 'Austin, Texas'
                },
                {
                    index: 3,
                    value: 'Barcelona'
                }
            ]
        },
        {
            artist: {
                name: 'Far East Movement',
                cover: farEast
            },
            question: 'Which city should we come to next for a live show?',
            tokens: {
                total: 20,
                left: 15
            },
            options: [
                {
                    index: 0,
                    value: 'New York City'
                }, 
                {
                    index: 1,
                    value: 'Paris'
                },
                {
                    index: 2,
                    value: 'Austin, Texas'
                },
                {
                    index: 3,
                    value: 'Barcelona'
                }
            ]
        }
    ];

    render() {
        const { mode } = this.state;
        const radioStyle = {
            display: 'block',
            height: '30px',
            lineHeight: '30px',
        };
        return(
            <div className="template-content artist-polls">
                <div className="head">
                    <h1 className="template-heading"><span>Artist Polls</span></h1>

                    <Affix offsetTop={20}>
                        <Radio.Group onChange={this.sortPolls} value={mode} style={{ marginBottom: 8 }}>
                            <Radio.Button value="recent">open now</Radio.Button>
                            <Radio.Button value="old">previous</Radio.Button>
                        </Radio.Group>
                    </Affix>
                    <div className="clear"></div>
                </div>
                <div className="polls-container">
                    <h3><span>3</span> POLLS OPEN NOW</h3>
                    <Row>
                        <RenderPolls pollsList={this.activePolls} />
                        <Col xs={24} md={12} xxl={8}>
                            <div className="polls-box">
                                <div className="polls-box-head">
                                    <p style={{paddingBottom:'20px'}}>
                                        <img src={farEast} className="artist-icon" alt="artist icon" /> <span className="artist">Far East Movement</span>
                                    </p>
                                    <p>
                                        <span className="question">
                                            Which city should we come to next for a live show?
                                        </span>
                                    </p>
                                    <p>
                                        <span className="tokensleft">
                                            <img src={clock} alt="clock-icon" /> 15 tokens until poll closes. 20 tokens received so far
                                        </span>
                                    </p>
                                </div>
                                <div className="polls-box-body">
                                    <div className="poll-options">
                                    <RadioGroup onChange={this.submitToken} value={this.state.value}>
                                        <Radio style={radioStyle} value={1}>New York City</Radio>
                                        <Radio style={radioStyle} value={2}>Paris</Radio>
                                        <Radio style={radioStyle} value={3}>Austin, Texas</Radio>
                                        <Radio style={radioStyle} value={4}>Barcelona</Radio>
                                    </RadioGroup>
                                    </div>
                                    <div>
                                        <p className="left-token">You have <span>10 fan tokens</span> for this artist</p>
                                    </div>
                                    <div className="poll-input">
                                        <input type="text" className="token-input" placeholder="Enter # of tokens to vote with" />
                                        <button className="btn btn-submitpoll">Submit vote</button>
                                    </div>
                                </div>
                            </div>
                        </Col>
                    </Row>
                </div>
            </div>
        );
    };
}

export default ArtistPolls;