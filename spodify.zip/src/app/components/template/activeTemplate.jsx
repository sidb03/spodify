import React, { Component } from "react";
import MySongs from "./mySongs/mySongs";
import Marketplace from "./marketplace/marketplace";
import ArtistPolls from "./artistPolls/artistPolls";
import About from "./about/about";
import FanTokens from "./fanTokens/fanTokens";

import TokenInfo from "../userDetails/tokenInfo/tokenInfo";

import "./activeTemplate.css";

const RenderTemplate = templateName => {
  switch (templateName) {
    case "mySongs":
      return <MySongs />;
    case "marketplace":
      return <Marketplace />;
    case "artistPolls":
      return <ArtistPolls />;
    case "fanTokens":
      return <FanTokens />;
    case "about":
      return <About />;
    default:
      return <ArtistPolls />;
  }
};

class ActiveTemplate extends Component {
  render() {
    const { template } = this.props;
    const { activeTemplate } = template.state;
    console.log("active template", activeTemplate);

    return (
      <div className="template">
        <div className="token-info">
          <TokenInfo />
        </div>
        { RenderTemplate(activeTemplate) }
      </div>
    );
  }
}

export default ActiveTemplate;
