import React from 'react'
import ReactDOM from 'react-dom'
import App from './app/App'
import { Provider } from 'unstated';

import { templateContainer } from './app/containers/TemplateContainer';

ReactDOM.render(
  <Provider inject={[templateContainer]}>
    <App />
  </Provider>,
  document.getElementById('root')
);
